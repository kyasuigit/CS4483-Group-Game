﻿using UnityEngine;
using System.Collections;

public class Settings{
    public bool fullscreen;
    public int textureQuality;
    public int antialiasing;
    public int vSync;
    public int resolutionIndex;
    public float volume;

}
