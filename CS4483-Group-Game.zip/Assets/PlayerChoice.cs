public static class PlayerChoice 
{
   public static string CharacterChoice { get; set; }
}
